<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://reichbaum.ru
 * @since      1.0.0
 *
 * @package    Rh_Consulting
 * @subpackage Rh_Consulting/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Rh_Consulting
 * @subpackage Rh_Consulting/includes
 * @author     Julia Reichbaum <reichbaumjulia@gmail.com>
 */
class Rh_Consulting_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
